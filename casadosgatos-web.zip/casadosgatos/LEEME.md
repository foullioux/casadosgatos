# Casa dos Gatos – web (GitHub Pages)

Fotos: súbelas a /img con estos nombres (webp o jpg; si usas jpg, cambia la extensión en PHOTOS dentro de index.html):
hero = terraza (foto principal, vertical) · g1 = jardín (grande, horizontal) · g2 = salón · g3 = cocina
g4 = dormitorio · g5 = cena en la terraza · g6 = baño (vertical) · g7 = exterior (horizontal) · g8 = detalle · g9 = vista

Dominio: está en el archivo CNAME (lacasadosgatos4.com). Si usas otro, cámbialo ahí y en index.html, robots.txt y sitemap.xml.

DNS en el registrador:
A     @    185.199.108.153
A     @    185.199.109.153
A     @    185.199.110.153
A     @    185.199.111.153
CNAME www  <tu-usuario>.github.io
